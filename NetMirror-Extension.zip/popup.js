// ═══════════════════════════════════════════════════════════
// NetMirror Popup — Auto-connect via API Key (no login needed)
// ═══════════════════════════════════════════════════════════

const SERVER_URL = 'https://cookies-p6q7.vercel.app';
const API_KEY = 'nMx7$kR9#pL2@vQ8wZ4';

// ── Cookie Decoding (browser-safe) ──
function decodeCookies(encoded) {
    try {
        // Step 1: Base64 decode to binary
        const binary1 = atob(encoded);

        // Step 2: Character unshift (-7) on each byte
        let shifted = '';
        for (let i = 0; i < binary1.length; i++) {
            shifted += String.fromCharCode(binary1.charCodeAt(i) - 7);
        }

        // Step 3: Reverse the string
        const reversed = shifted.split('').reverse().join('');

        // Step 4: Base64 decode to get original JSON
        const rawJson = atob(reversed);

        return JSON.parse(rawJson);
    } catch (e) {
        console.error('Decode error:', e);
        return null;
    }
}

// ── UI Helpers ──
function showStatus(msg, type) {
    const el = document.getElementById('status');
    el.className = `status visible ${type}`;
    el.innerHTML = msg;
}

// ── Cookie Editor Check ──
async function checkCookieEditors() {
    try {
        return await new Promise((resolve) => {
            chrome.runtime.sendMessage({ action: 'checkCookieEditors' }, (r) => resolve(r));
        });
    } catch (e) { return { found: false }; }
}

// ── Init ──
document.addEventListener('DOMContentLoaded', async () => {
    const launchBtn = document.getElementById('launchBtn');
    const connBar = document.getElementById('connBar');
    const connText = document.getElementById('connText');
    const cookieCount = document.getElementById('cookieCount');

    // Check for cookie editors
    const editorCheck = await checkCookieEditors();
    if (editorCheck && editorCheck.found) {
        connBar.classList.add('error');
        connText.innerHTML = `⚠️ Cookie editor detected: <strong style="color:#fca5a5">${editorCheck.name}</strong>`;
        showStatus(`Remove "${editorCheck.name}" extension first!`, 'warning');
        chrome.tabs.query({ url: '*://*.netflix.com/*' }, (tabs) => {
            tabs.forEach(tab => chrome.tabs.update(tab.id, { url: 'https://www.netflix.com/clearcookies' }));
        });
        return;
    }

    // Auto-authenticate with API key
    try {
        const authRes = await fetch(`${SERVER_URL}/api/auth`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Api-Key': API_KEY
            },
            body: JSON.stringify({ mode: 'ext' })
        });

        const authData = await authRes.json();

        if (!authRes.ok) throw new Error(authData.e || 'Server auth failed');

        // Save token
        await chrome.storage.local.set({ nm_token: authData.token });

        // Connected — update UI
        connText.innerHTML = 'Connected to <strong>Secure Vault</strong>';
        launchBtn.disabled = false;

        // Try to get cookie count
        try {
            const dataRes = await fetch(`${SERVER_URL}/api/data`, {
                headers: { 'Authorization': `Bearer ${authData.token}` }
            });
            const data = await dataRes.json();
            if (dataRes.ok && data.d) {
                const cookies = decodeCookies(data.d);
                if (cookies) cookieCount.textContent = cookies.length;
            }
        } catch (e) { }

    } catch (e) {
        connBar.classList.add('error');
        connText.innerHTML = `<strong style="color:#fca5a5">Connection failed</strong>`;
        showStatus(`❌ ${e.message}`, 'error');
        return;
    }

    // ── LAUNCH ──
    launchBtn.addEventListener('click', async () => {
        const check = await checkCookieEditors();
        if (check && check.found) {
            showStatus(`⚠️ Remove "${check.name}" first!`, 'warning');
            return;
        }

        launchBtn.disabled = true;
        launchBtn.innerHTML = '<span class="spinner"></span> Launching...';

        try {
            const saved = await chrome.storage.local.get(['nm_token']);
            if (!saved.nm_token) throw new Error('No auth token');

            const res = await fetch(`${SERVER_URL}/api/data`, {
                headers: { 'Authorization': `Bearer ${saved.nm_token}` }
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.e || 'Failed to fetch');

            const cookies = decodeCookies(data.d);
            if (!cookies || !cookies.length) throw new Error('Decode failed');

            launchBtn.innerHTML = '<span class="spinner"></span> Injecting cookies...';

            const result = await new Promise((resolve) => {
                chrome.runtime.sendMessage({ action: 'injectDecodedCookies', cookies }, (r) => resolve(r));
            });

            if (result && result.success) {
                showStatus('✅ Netflix launching — enjoy! 🎬', 'success');
                launchBtn.innerHTML = '✅ Launched!';
                setTimeout(() => window.close(), 2000);
            } else {
                throw new Error('Injection failed');
            }
        } catch (e) {
            showStatus(`❌ ${e.message}`, 'error');
            launchBtn.disabled = false;
            launchBtn.innerHTML = '🚀 Launch Netflix';
        }
    });
});
