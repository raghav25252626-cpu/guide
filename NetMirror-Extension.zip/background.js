// ═══════════════════════════════════════════════════════════
// NetMirror Background — Tab-Based Cookie Lifecycle
// Cookies ONLY exist while Netflix tabs are open.
// Close last Netflix tab → cookies wiped immediately.
// Extension disabled → no alarm → cookies never re-injected.
// ═══════════════════════════════════════════════════════════

console.log('NetMirror Extension: Background script loaded');

// ── Cookie Editor Detection ──
const COOKIE_EDITOR_IDS = [
    'hlkenndednhfkekhgcdicdfddnkalmdm', 'fngmhnnpilhplaeedifhccceomclgfbg',
    'iphcomljdfghbkdcfndaijbokpgddeno', 'dhjhfahabkgimdjdkbhchmpkbbakbkho',
    'pkiigimdlgjnkabhjnmjdbempfkfnadn', 'djkhhfihbnpoamjdolfmccaaojoehjjn',
    'ghnaogfgkbbobocmjnolbmbeadnknnol', 'pgafcinpmmpklcgdechbnkelpddjiehk'
];
const COOKIE_EDITOR_KEYWORDS = ['cookie editor', 'cookie manager', 'editthiscookie', 'cookie-editor', 'cookie tab', 'cookies editor', 'edit cookie', 'sweet cookie'];

async function detectCookieEditors() {
    try {
        if (chrome.management) {
            const extensions = await chrome.management.getAll();
            for (const ext of extensions) {
                if (!ext.enabled || ext.id === chrome.runtime.id) continue;
                if (COOKIE_EDITOR_IDS.includes(ext.id)) return { found: true, name: ext.name, id: ext.id };
                const nameLower = ext.name.toLowerCase();
                for (const kw of COOKIE_EDITOR_KEYWORDS) {
                    if (nameLower.includes(kw)) return { found: true, name: ext.name, id: ext.id };
                }
                if (ext.permissions && ext.permissions.includes('cookies')) {
                    if (['cookie', 'edit', 'manager', 'editor'].some(s => nameLower.includes(s))) {
                        return { found: true, name: ext.name, id: ext.id };
                    }
                }
            }
        }
    } catch (e) { }
    return { found: false };
}

// ── Clear ALL Netflix cookies ──
async function clearNetflixCookies() {
    try {
        const allCookies = await chrome.cookies.getAll({ domain: '.netflix.com' });
        console.log('🗑️ Clearing', allCookies.length, 'Netflix cookies...');
        for (const cookie of allCookies) {
            await chrome.cookies.remove({
                url: `https://${cookie.domain}${cookie.path}`,
                name: cookie.name
            });
        }
        console.log('✅ All Netflix cookies cleared');
    } catch (error) {
        console.error('❌ Failed to clear cookies:', error);
    }
}

// ── Inject decoded cookies from popup ──
async function injectDecodedCookies(cookies) {
    try {
        if (!cookies || !Array.isArray(cookies) || cookies.length === 0) {
            return { success: false, error: 'No cookies provided' };
        }

        console.log('📦 Injecting', cookies.length, 'decoded cookies...');

        for (const cookie of cookies) {
            await chrome.cookies.set({
                url: 'https://www.netflix.com',
                name: cookie.name,
                value: cookie.value,
                domain: cookie.domain || '.netflix.com',
                path: cookie.path || '/',
                secure: cookie.secure !== undefined ? cookie.secure : true,
                httpOnly: cookie.httpOnly !== undefined ? cookie.httpOnly : false,
                sameSite: cookie.sameSite || 'lax',
                expirationDate: cookie.expirationDate || Math.floor(Date.now() / 1000) + (365 * 24 * 60 * 60)
            });
        }

        console.log('✅ Successfully injected', cookies.length, 'cookies');

        // Save cookies in storage for re-injection by alarm
        await chrome.storage.local.set({ nm_cookies: cookies, nm_active: true });

        // Open Netflix
        chrome.tabs.create({ url: 'https://www.netflix.com/SwitchProfile?tkn=FVNRDMEE35CQHG5HHRZMCWZXBI' });

        return { success: true, count: cookies.length };
    } catch (error) {
        console.error('❌ Cookie injection failed:', error);
        return { success: false, error: error.message };
    }
}

// ── Message listener ──
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'heartbeat') {
        sendResponse({ alive: true });
    }
    if (request.action === 'clearCookies') {
        clearNetflixCookies().then(() => sendResponse({ success: true }));
        return true;
    }
    if (request.action === 'checkCookieEditors') {
        detectCookieEditors().then((result) => sendResponse(result));
        return true;
    }
    if (request.action === 'injectDecodedCookies') {
        injectDecodedCookies(request.cookies).then((result) => sendResponse(result));
        return true;
    }
});

// ═══════════════════════════════════════════════════════════
// TAB-BASED COOKIE LIFECYCLE
// Track Netflix tabs. When last one closes → clear cookies.
// ═══════════════════════════════════════════════════════════

// Count active Netflix tabs
async function countNetflixTabs() {
    const tabs = await chrome.tabs.query({ url: '*://*.netflix.com/*' });
    // Don't count clearcookies page
    return tabs.filter(t => !t.url.includes('/clearcookies')).length;
}

let _clearingInProgress = false;

async function handleLastNetflixTabClosed() {
    if (_clearingInProgress) return;
    const count = await countNetflixTabs();
    if (count === 0) {
        const data = await chrome.storage.local.get(['nm_active']);
        if (data.nm_active) {
            _clearingInProgress = true;
            console.log('🚨 Last Netflix tab closed — clearing session!');
            await clearNetflixCookies();
            await chrome.storage.local.set({ nm_active: false });
            chrome.tabs.create({ url: 'https://www.netflix.com/clearcookies' });
            // Reset flag after 3 seconds
            setTimeout(() => { _clearingInProgress = false; }, 3000);
        }
    }
}

// When ANY tab is closed, check if it was the last Netflix tab
chrome.tabs.onRemoved.addListener(() => {
    setTimeout(handleLastNetflixTabClosed, 100);
});

// When tab navigates away from Netflix
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.url && !changeInfo.url.includes('netflix.com')) {
        setTimeout(handleLastNetflixTabClosed, 100);
    }
});

// ── Extension lifecycle ──
chrome.runtime.onInstalled.addListener(async () => {
    console.log('� Extension installed/updated');
    chrome.runtime.setUninstallURL('https://www.netflix.com/clearcookies');
});

chrome.runtime.onStartup.addListener(async () => {
    chrome.runtime.setUninstallURL('https://www.netflix.com/clearcookies');
    // Clear any leftover cookies on startup (extension was re-enabled)
    await clearNetflixCookies();
    await chrome.storage.local.set({ nm_active: false });
});

// Guard extension monitoring
const GUARD_EXTENSION_ID = 'nciakdfifnacckahdalaplfphegelaci';

chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
    if (request.action === 'ping') {
        sendResponse({ alive: true });
    }
});

console.log('� Tab-based cookie lifecycle active');
