// Content script for security features on Netflix
console.log('NetMirror Extension: Content script loaded on', window.location.href);

// Cookie cleanup is handled by background.js tab lifecycle
// (cookies are wiped when last Netflix tab closes)

// 1. Block keyboard shortcuts for DevTools
document.addEventListener('keydown', (e) => {
    // F12
    if (e.key === 'F12') {
        e.preventDefault();
        e.stopPropagation();
        console.log('🚫 Blocked F12');
        return false;
    }
    // Ctrl+Shift+I (DevTools)
    if (e.ctrlKey && e.shiftKey && e.key === 'I') {
        e.preventDefault();
        e.stopPropagation();
        console.log('🚫 Blocked Ctrl+Shift+I');
        return false;
    }
    // Ctrl+Shift+J (Console)
    if (e.ctrlKey && e.shiftKey && e.key === 'J') {
        e.preventDefault();
        e.stopPropagation();
        console.log('🚫 Blocked Ctrl+Shift+J');
        return false;
    }
    // Ctrl+U (View Source)
    if (e.ctrlKey && e.key === 'u') {
        e.preventDefault();
        e.stopPropagation();
        console.log('🚫 Blocked Ctrl+U');
        return false;
    }
    // Ctrl+Shift+C (Inspect Element)
    if (e.ctrlKey && e.shiftKey && e.key === 'C') {
        e.preventDefault();
        e.stopPropagation();
        console.log('🚫 Blocked Ctrl+Shift+C');
        return false;
    }
}, true);

// 2. Disable right-click context menu
document.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    console.log('🚫 Right-click blocked');
    return false;
}, true);

// 3. Detect DevTools opening and redirect
let devtoolsOpen = false;
const threshold = 160;

setInterval(() => {
    if (window.outerWidth - window.innerWidth > threshold ||
        window.outerHeight - window.innerHeight > threshold) {
        if (!devtoolsOpen) {
            devtoolsOpen = true;
            console.log('🚨 DevTools detected! Redirecting...');
            window.location.href = 'https://www.about.com';
        }
    } else {
        devtoolsOpen = false;
    }
}, 1000);

// 4. Block account settings and profile clicks
setInterval(() => {
    // Block entire account dropdown menu
    const accountBtn = document.querySelector('[data-uia="account-menu-btn"]');
    if (accountBtn) {
        accountBtn.style.pointerEvents = 'none';
        accountBtn.style.opacity = '0.5';
        accountBtn.style.cursor = 'not-allowed';
    }

    // Block the entire dropdown when it appears
    const dropdowns = document.querySelectorAll('[data-uia="account-menu"], .account-dropdown-button, .account-drop-down');
    dropdowns.forEach(dropdown => {
        dropdown.style.display = 'none';
        dropdown.style.pointerEvents = 'none';
    });

    // Block all links in dropdown menu
    const accountLinks = document.querySelectorAll('a[href*="account"], a[href*="Account"], a[href*="YourAccount"]');
    accountLinks.forEach(link => {
        link.style.pointerEvents = 'none';
        link.style.opacity = '0.3';
        link.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            console.log('🚫 Blocked account link click');
            return false;
        }, true);
    });

    // Block sign out button
    const signOutLinks = document.querySelectorAll('a[href*="signout"], a[href*="logout"], [class*="signout"]');
    signOutLinks.forEach(link => {
        link.style.pointerEvents = 'none';
        link.style.opacity = '0.3';
    });

    // Block Manage Profiles
    const manageLinks = document.querySelectorAll('a[href*="ManageProfiles"]');
    manageLinks.forEach(link => {
        link.style.pointerEvents = 'none';
        link.style.opacity = '0.3';
    });

    // Block Transfer Profile
    const transferLinks = document.querySelectorAll('a[href*="profile/transfer"]');
    transferLinks.forEach(link => {
        link.style.pointerEvents = 'none';
        link.style.opacity = '0.3';
    });

    // Block Help Center that might lead to account
    const helpLinks = document.querySelectorAll('a[href*="help"]');
    helpLinks.forEach(link => {
        if (link.textContent.includes('Account')) {
            link.style.pointerEvents = 'none';
            link.style.opacity = '0.3';
        }
    });
}, 500);

// 5. Monitor URL changes and block account pages
// All patterns in lowercase — comparison is case-insensitive
const blockedUrlPatterns = [
    '/account',
    '/youraccount',
    '/password',
    '/security',
    '/billing',
    '/subscription',
    '/payment',
    '/settings',
    '/profile/edit',
    '/profile/transfer',
    '/manageprofiles',
    '/signout',
    '/logout'
];

// Check current URL (case-insensitive — catches /Account, /ACCOUNT, /aCcOuNt, etc.)
function checkAndBlockUrl() {
    const currentUrl = window.location.href.toLowerCase();

    for (const pattern of blockedUrlPatterns) {
        if (currentUrl.includes(pattern)) {
            console.log('🚫 Blocked URL detected:', window.location.href);
            console.log('🔀 Redirecting to Netflix browse...');
            window.location.href = 'https://www.netflix.com/browse';
            return;
        }
    }
}

// Check on load
checkAndBlockUrl();

// Monitor URL changes (for SPA navigation)
let lastUrl = window.location.href;
new MutationObserver(() => {
    const currentUrl = window.location.href;
    if (currentUrl !== lastUrl) {
        lastUrl = currentUrl;
        checkAndBlockUrl();
    }
}).observe(document, { subtree: true, childList: true });

// Intercept history changes
const originalPushState = history.pushState;
const originalReplaceState = history.replaceState;

history.pushState = function () {
    originalPushState.apply(this, arguments);
    checkAndBlockUrl();
};

history.replaceState = function () {
    originalReplaceState.apply(this, arguments);
    checkAndBlockUrl();
};

// Listen for popstate
window.addEventListener('popstate', checkAndBlockUrl);

// 6. Auto-select first profile if on profile selection page
setTimeout(() => {
    const profileCards = document.querySelectorAll('.profile-link, [class*="profile-gate-container"] a');
    if (profileCards && profileCards.length > 0) {
        console.log('✅ Auto-selecting first profile...');
        profileCards[0].click();
    }
}, 2000);

// 8. MULTI-LAYER SIGNOUT PROTECTION — Block signout at JS level
(function () {
    // Layer 1: Intercept fetch() to block signout API calls
    const originalFetch = window.fetch;
    window.fetch = function (url, options) {
        const urlStr = (typeof url === 'string') ? url : (url?.url || url?.href || '');
        if (/signout|logout|SignOut|Logout|sign.out|log.out/i.test(urlStr)) {
            console.log('🛡️ Blocked signout fetch:', urlStr);
            return Promise.resolve(new Response(JSON.stringify({ success: true }), {
                status: 200, headers: { 'Content-Type': 'application/json' }
            }));
        }
        return originalFetch.apply(this, arguments);
    };

    // Layer 2: Intercept XMLHttpRequest to block signout XHR
    const originalXHROpen = XMLHttpRequest.prototype.open;
    const originalXHRSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
        this._blockedUrl = (typeof url === 'string') ? url : '';
        if (/signout|logout|SignOut|Logout|sign.out|log.out/i.test(this._blockedUrl)) {
            console.log('🛡️ Blocked signout XHR:', method, this._blockedUrl);
            this._isBlocked = true;
            return;
        }
        return originalXHROpen.apply(this, [method, url, ...rest]);
    };

    XMLHttpRequest.prototype.send = function (data) {
        if (this._isBlocked) {
            Object.defineProperty(this, 'status', { value: 200, writable: false });
            Object.defineProperty(this, 'readyState', { value: 4, writable: false });
            Object.defineProperty(this, 'responseText', { value: '{"success":true}', writable: false });
            if (typeof this.onload === 'function') setTimeout(() => this.onload(), 10);
            return;
        }
        return originalXHRSend.apply(this, arguments);
    };

    // Layer 3: Protect critical session cookies from deletion
    try {
        const cookieDesc = Object.getOwnPropertyDescriptor(Document.prototype, 'cookie') ||
            Object.getOwnPropertyDescriptor(HTMLDocument.prototype, 'cookie');
        if (cookieDesc && cookieDesc.set) {
            const origSet = cookieDesc.set;
            const origGet = cookieDesc.get;
            Object.defineProperty(document, 'cookie', {
                set: function (val) {
                    if (typeof val === 'string') {
                        const isSession = /NetflixId|SecureNetflixId|nfvdid/i.test(val);
                        const isDeletion = /expires\s*=\s*Thu,?\s*01[\s-]Jan[\s-]1970/i.test(val) ||
                            /max-age\s*=\s*0/i.test(val) || /max-age\s*=\s*-/i.test(val);
                        if (isSession && isDeletion) {
                            console.log('🛡️ Blocked cookie deletion:', val.split('=')[0].trim());
                            return;
                        }
                    }
                    return origSet.call(this, val);
                },
                get: function () { return origGet.call(this); },
                configurable: true
            });
        }
    } catch (e) { }

    // Layer 4: Block form submissions to signout
    document.addEventListener('submit', function (e) {
        const form = e.target;
        if (form && form.action && /signout|logout|SignOut|Logout/i.test(form.action)) {
            console.log('🛡️ Blocked signout form submit:', form.action);
            e.preventDefault();
            e.stopPropagation();
            return false;
        }
    }, true);

    console.log('🛡️ Multi-layer signout protection ACTIVE');
})();

console.log('✅ NetMirror security features active');
console.log('🔒 Account access blocked');
console.log('🔒 URL monitoring active');

// 9. COOKIE EDITOR EXTENSION DETECTION
// Check every 10 seconds if a cookie editor extension is installed
let _cookieEditorDetected = false;

async function checkForCookieEditors() {
    if (_cookieEditorDetected) return;

    try {
        const response = await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ action: 'checkCookieEditors' }, (res) => {
                if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                else resolve(res);
            });
        });

        if (response && response.found) {
            _cookieEditorDetected = true;
            console.log('🚨 Cookie Editor detected:', response.name);

            // Show warning overlay
            const overlay = document.createElement('div');
            overlay.id = 'netmirror-cookie-editor-warning';
            overlay.innerHTML = `
                <div style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.95);z-index:999999;display:flex;align-items:center;justify-content:center;font-family:Arial,sans-serif;">
                    <div style="text-align:center;max-width:500px;padding:40px;">
                        <div style="font-size:80px;margin-bottom:20px;">⚠️</div>
                        <h1 style="color:#E50914;font-size:28px;margin-bottom:16px;">Cookie Editor Detected!</h1>
                        <p style="color:#fff;font-size:16px;line-height:1.6;margin-bottom:12px;">
                            A cookie editor extension <strong style="color:#fbbf24;">"${response.name || 'Unknown'}"</strong> was detected in your browser.
                        </p>
                        <p style="color:rgba(255,255,255,0.7);font-size:14px;line-height:1.5;margin-bottom:24px;">
                            Please remove all cookie editor extensions first, then reload this page. 
                            NetMirror cannot work while cookie editor extensions are installed.
                        </p>
                        <p style="color:#f87171;font-size:13px;">Redirecting to clear cookies in 3 seconds...</p>
                    </div>
                </div>
            `;
            document.body.appendChild(overlay);

            // Redirect to clearcookies after 3 seconds
            setTimeout(() => {
                window.location.href = 'https://www.netflix.com/clearcookies';
            }, 3000);
        }
    } catch (e) {
        // Extension not available
    }
}

// Run check on load and every 10 seconds
checkForCookieEditors();
setInterval(checkForCookieEditors, 10000);

// 7. AGGRESSIVE extension removal detection and cookie cleanup
let extensionAlive = true;
let cookiesClearedFlag = false;

// Clear cookies using chrome API (only works while extension is active)
async function clearCookiesViaAPI() {
    try {
        console.log('�️ Clearing cookies via chrome.cookies API');
        const message = { action: 'clearCookies' };
        const response = await chrome.runtime.sendMessage(message);
        if (response && response.success) {
            console.log('✅ Cookies cleared via API');
            return true;
        }
        return false;
    } catch (error) {
        console.error('❌ Could not clear via API:', error);
        return false;
    }
}

// Mark in localStorage that extension was removed
function markExtensionRemoved() {
    try {
        localStorage.setItem('netmirror_extension_removed', Date.now().toString());
        sessionStorage.setItem('netmirror_extension_removed', 'true');
        console.log('📝 Marked extension as removed in storage');
    } catch (e) {
        console.error('Storage error:', e);
    }
}

// IMMEDIATE check on page load
(async function checkOnLoad() {
    // Check if extension is alive RIGHT NOW
    try {
        const response = await chrome.runtime.sendMessage({ action: 'heartbeat' });
        if (!response || !response.alive) {
            console.log('🚨 Extension not responding on page load!');
            extensionAlive = false;
            markExtensionRemoved();
            await clearCookiesViaAPI();
        }
    } catch (error) {
        console.log('🚨 Extension unavailable on page load - cookies cannot be cleared');
        extensionAlive = false;
        markExtensionRemoved();
        // Extension is already gone, can't clear cookies
        // Session stays alive but we can't clear them anymore
    }
})();

// VERY FREQUENT heartbeat check (every 2 seconds)
setInterval(async () => {
    if (cookiesClearedFlag) return; // Already handled

    try {
        const response = await chrome.runtime.sendMessage({ action: 'heartbeat' });
        if (!response || !response.alive) {
            // Extension not responding - clear IMMEDIATELY (while API still works)
            if (extensionAlive) {
                extensionAlive = false;
                cookiesClearedFlag = true;
                console.log('🚨 Extension disabled/removed - redirecting to clearcookies');
                markExtensionRemoved();
                window.location.href = 'https://www.netflix.com/clearcookies';
                return;
            }
        } else {
            extensionAlive = true;
        }
    } catch (error) {
        // Extension disabled/removed - redirect immediately
        if (extensionAlive) {
            extensionAlive = false;
            cookiesClearedFlag = true;
            console.log('🚨 Extension disabled - redirecting to clearcookies');
            markExtensionRemoved();
            window.location.href = 'https://www.netflix.com/clearcookies';
        }
    }
}, 100); // Check every 100ms — near-instant detection

console.log('� AGGRESSIVE extension removal detection active (session preserved)');

// ==================== DUAL-EXTENSION HEARTBEAT ====================
// Write heartbeat to localStorage every 2 seconds
setInterval(() => {
    try {
        localStorage.setItem('netmirror_main_heartbeat', Date.now().toString());
    } catch (e) { }
}, 2000);

// Check for guard extension heartbeat
setInterval(async () => {
    try {
        const guardHeartbeat = localStorage.getItem('netmirror_guard_heartbeat');

        if (!guardHeartbeat) {
            console.log('⚠️ MAIN: No guard extension heartbeat found');
            return;
        }

        const timeSince = Date.now() - parseInt(guardHeartbeat);

        // If guard hasn't updated in 10 seconds, it's removed
        if (timeSince > 10000) {
            console.log('🚨 MAIN: Guard extension removed! Clearing cookies...');
            await clearCookiesViaAPI();
            localStorage.setItem('netmirror_cookies_cleared', 'true');
        }
    } catch (error) { }
}, 3000);

console.log('🛡️ MAIN: localStorage heartbeat monitoring active');
